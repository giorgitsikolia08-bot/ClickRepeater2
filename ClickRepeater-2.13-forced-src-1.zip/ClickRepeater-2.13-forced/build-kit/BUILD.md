# ClickRepeater — отчёт о сборке

Собрано из архива `ClickRepeater.zip` без изменений в исходниках
(`src/ModEntry.cpp`, `CMakeLists.txt`, `manifest.json.in` не редактировались).

## Итог

- `ClickRepeater.levipack` — 277 114 байт
- sha256: `b70fabf2ac82b67d18fbb0d735424d8195ef0e5fe2ad055de92b9aa34dfdd404`

## Параметры сборки

| Параметр | Значение |
|---|---|
| ABI | `arm64-v8a` (ELF64, AArch64) |
| minSdk / platform | `android-28` |
| STL | `c++_static` (libc++ встроен в .so) |
| Build type | `Release` (`-O3 -DNDEBUG`) |
| NDK | r28c (28.2.13676358), API 28 sysroot |
| SDK-заголовки | `preloader-android` тег **0.2.2** (проверено: `pl/Mod.hpp`, `pl/Input.hpp`, `pl/ModMenu.hpp`) |
| Компилятор | нативный aarch64 clang 18.1.8 + `ld.lld`, т.к. clang внутри NDK собран под x86_64 |

Флаги линковки из проекта применены: `-Wl,-z,max-page-size=16384`
(в ELF `LOAD ... 0x4000`) и `-Wl,--unresolved-symbols=ignore-all`.

## Проверки бинарника

- `readelf -h`: `ELF64`, `DYN`, `Machine: AArch64`.
- `readelf -d`: зависимости только `liblog.so`, `libm.so`, `libdl.so`, `libc.so`;
  `libc++_shared.so` не требуется.
- Экспортирован символ регистрации мода: `PLGetModRegistration`.
- Неразрешённые (резолвятся лаунчером при загрузке) символы — ровно 4:
  `pl::modmenu::registerModule`, `pl::modmenu::unregisterModule`,
  `pl::input::registerKeyCallback`, `pl::input::registerMouseCallback`.
- SONAME: `libclick_repeater.so`.

## Содержимое `.levipack`

```
click_repeater/manifest.json
click_repeater/libclick_repeater.so
```

`manifest.json`:

```json
{
  "type": "preload-native",
  "name": "Click Repeater",
  "author": "ClickRepeater",
  "version": "0.1.0",
  "entry": "libclick_repeater.so",
  "icon": "",
  "minecraft_versions": ["1.26.52.*"],
  "overwrite_files": [],
  "overwrite_folders": []
}
```

## Что НЕ проверено

Сборка не запускалась в Minecraft — на этом хосте нет игры и устройства.
Работоспособность автоклика **не подтверждена**. Открытые вопросы из README
проекта остаются: какие коды кнопок приходят в mouse-callback, принимает ли
игра синтетические `MotionEvent`, доступен ли `ActivityThread.mActivities`.

## Файлы

- `build-kit/build-aarch64.sh` — повтор сборки.
- `build-kit/android-aarch64-toolchain.cmake` — CMake-тулчейн для ARM64-хоста.
