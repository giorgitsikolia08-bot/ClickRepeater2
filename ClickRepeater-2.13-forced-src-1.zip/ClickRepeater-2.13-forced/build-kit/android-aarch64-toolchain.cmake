# CMake toolchain for building Android arm64-v8a on an aarch64 Linux host.
# The NDK r28c prebuilt clang is x86_64-only and cannot run here, so we use the
# host's native clang-18 with the NDK sysroot/resource dir. Same target flags as
# the NDK toolchain would produce.
set(CMAKE_SYSTEM_NAME Android)
set(CMAKE_SYSTEM_VERSION 28)
set(CMAKE_SYSTEM_PROCESSOR aarch64)

set(CMAKE_ANDROID_ARCH_ABI arm64-v8a)
set(CMAKE_ANDROID_API 28)
set(CMAKE_ANDROID_STL_TYPE c++_static)

set(_ndk "/tmp/opencode/ndk_extract/android-ndk-r28c")
set(CMAKE_ANDROID_NDK "${_ndk}")
set(CMAKE_ANDROID_NDK_TOOLCHAIN_UNIFIED "${_ndk}/toolchains/llvm/prebuilt/linux-x86_64")
set(CMAKE_SYSROOT "${_ndk}/toolchains/llvm/prebuilt/linux-x86_64/sysroot")

set(_llvm "/tmp/cx18o/usr/lib/llvm-18/bin")
set(CMAKE_C_COMPILER "${_llvm}/clang")
set(CMAKE_CXX_COMPILER "${_llvm}/clang++")
set(CMAKE_ASM_COMPILER "${_llvm}/clang")
set(CMAKE_AR "${_llvm}/llvm-ar")
set(CMAKE_RANLIB "${_llvm}/llvm-ranlib")
set(CMAKE_STRIP "${_llvm}/llvm-strip")

set(CMAKE_C_COMPILER_TARGET aarch64-linux-android28)
set(CMAKE_CXX_COMPILER_TARGET aarch64-linux-android28)

set(_res "${_ndk}/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/19")
set(CMAKE_C_FLAGS_INIT "-resource-dir=${_res} --rtlib=compiler-rt -stdlib=libc++")
set(CMAKE_CXX_FLAGS_INIT "-resource-dir=${_res} --rtlib=compiler-rt -stdlib=libc++")

set(CMAKE_FIND_ROOT_PATH "${CMAKE_SYSROOT}")
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
