// Click Repeater - LeviLaunchroid native mod (PROTOTYPE).
//
// Hold Ctrl + hold a mouse button  =>  the mod repeats that click at a configurable rate.
//
// NOT VERIFIED ON A DEVICE (read README.md, section "What to report"):
//   1. which button codes the launcher delivers to the mouse callback (defaults: 1 = left, 2 = right,
//      both are changeable in the mod menu, every mouse event is written to the log);
//   2. whether Minecraft accepts the synthetic MotionEvents (every step of the injection is logged).
//
// Only SDK APIs from preloader-android 0.2.2 headers are used: pl/Mod.hpp, pl/Input.hpp, pl/ModMenu.hpp.
#include <pl/Input.hpp>
#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <string_view>
#include <thread>

namespace clickrepeater {
namespace {

using Clock = std::chrono::steady_clock;

constexpr const char *kModuleId = "click_repeater";
constexpr const char *kModuleLmb = "click_repeater_lmb";
constexpr const char *kModuleRmb = "click_repeater_rmb";

// Diagnostics are also written to a text file so the user can attach it
// without pulling logcat from the device.
void diag(std::string_view line) {
  static const char *paths[] = {
      "/sdcard/Download/ClickRepeater-diag.txt",
      "/storage/emulated/0/Download/ClickRepeater-diag.txt",
      "/data/local/tmp/ClickRepeater-diag.txt",
  };
  for (const char *path : paths) {
    FILE *f = std::fopen(path, "a");
    if (!f) continue;
    const auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
                         std::chrono::system_clock::now().time_since_epoch())
                         .count();
    std::fprintf(f, "[%lld] %.*s\n", (long long)now, (int)line.size(), line.data());
    std::fclose(f);
    return;
  }
}

// Android key codes (AKEYCODE_CTRL_LEFT / AKEYCODE_CTRL_RIGHT).
constexpr int kKeyCtrlLeft = 113;
constexpr int kKeyCtrlRight = 114;
constexpr int kKeyShiftLeft = 59;
constexpr int kKeyShiftRight = 60;
constexpr int kKeyAltLeft = 56;
constexpr int kKeyAltRight = 125;
// Android KeyEvent codes for physical mouse buttons. LeviLauncher maps these
// to MotionEvent.BUTTON_PRIMARY / BUTTON_SECONDARY before sending them to mods.
constexpr jint kKeyMouseLeft = 96;   // KEYCODE_BUTTON_1
constexpr jint kKeyMouseRight = 97;  // KEYCODE_BUTTON_2

// Android MotionEvent / InputDevice constants.
constexpr jint kActionDown = 0;
constexpr jint kActionUp = 1;
constexpr jint kSourceKeyboard = 0x100;   // InputDevice.SOURCE_KEYBOARD
constexpr jint kSourceMouse = 0x2002;     // InputDevice.SOURCE_MOUSE
constexpr jint kActionButtonPress = 11;   // MotionEvent.ACTION_BUTTON_PRESS
constexpr jint kActionButtonRelease = 12; // MotionEvent.ACTION_BUTTON_RELEASE
constexpr jint kToolTypeMouse = 3;        // MotionEvent.TOOL_TYPE_MOUSE
constexpr jint kButtonPrimary = 1;        // MotionEvent.BUTTON_PRIMARY
constexpr jint kButtonSecondary = 2;      // MotionEvent.BUTTON_SECONDARY

int64_t nowMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(
             Clock::now().time_since_epoch())
      .count();
}

// ---------------------------------------------------------------- shared state
struct State {
  std::atomic<bool> active{false};         // mod enabled by the launcher
  std::atomic<bool> lmbModuleEnabled{true};
  std::atomic<bool> rmbModuleEnabled{true};
  std::atomic<bool> ctrlLeft{false};
  std::atomic<bool> ctrlRight{false};
  std::atomic<bool> shiftLeft{false};
  std::atomic<bool> shiftRight{false};
  std::atomic<bool> altLeft{false};
  std::atomic<bool> altRight{false};
  std::atomic<bool> lmbHeld{false};
  std::atomic<bool> rmbHeld{false};
  std::atomic<bool> lmbOn{true};
  std::atomic<bool> rmbOn{true};
  std::atomic<int> lmbCps{20};
  std::atomic<int> rmbCps{20};
  std::atomic<int> lmbCode{1};
  std::atomic<int> rmbCode{2};
  // Modifier required before repeating: 0 = none, 1 = Ctrl, 2 = Shift, 3 = Alt.
  std::atomic<int> lmbMod{0};
  std::atomic<int> rmbMod{0};
  // Injection method: 0 = Key(kbd src), 1 = Key(mouse src), 2 = Touch, 3 = Full mouse sequence.
  std::atomic<int> lmbMethod{4};
  std::atomic<int> rmbMethod{4};
  std::atomic<float> lastX{-1.0f};
  std::atomic<float> lastY{-1.0f};
  std::atomic<int64_t> suppressUntilMs{0}; // ignore our own synthetic events
  std::atomic<size_t> workerTid{0};        // hash of the injector thread id
  // Expected echoes of OUR OWN injected click (down + up per button). The
  // launcher turns injected key 96/97 back into mouse callbacks; those must
  // not change the held-state, but real events must never be swallowed.
  std::atomic<int> expDown[2]{};
  std::atomic<int> expUp[2]{};
  std::atomic<int64_t> expDeadline[2]{};
};

State g;
pl::log::Logger *gLog = nullptr;

bool parseBool(std::string_view v) {
  return v == "1" || v == "true" || v == "True" || v == "TRUE" || v == "on";
}

int parseInt(std::string_view v, int fallback, int lo, int hi) {
  const std::string s(v);
  char *end = nullptr;
  const long n = std::strtol(s.c_str(), &end, 10);
  if (end == s.c_str()) return fallback;
  return static_cast<int>(std::clamp<long>(n, lo, hi));
}

// ---------------------------------------------------------------- input callbacks
bool onKey(const pl::input::KeyEvent &e) {
  if (!g.active.load()) return false;

  if (e.keyCode == kKeyCtrlLeft) g.ctrlLeft = e.isKeyDown;
  if (e.keyCode == kKeyCtrlRight) g.ctrlRight = e.isKeyDown;
  if (e.keyCode == kKeyShiftLeft) g.shiftLeft = e.isKeyDown;
  if (e.keyCode == kKeyShiftRight) g.shiftRight = e.isKeyDown;
  if (e.keyCode == kKeyAltLeft) g.altLeft = e.isKeyDown;
  if (e.keyCode == kKeyAltRight) g.altRight = e.isKeyDown;
  return false; // never swallow real input
}

bool onMouse(const pl::input::MouseEvent &e) {
  if (!g.active.load()) return false;
  // Only ignore the exact echo of our own injected click. A time window also
  // swallowed the user's REAL button-up (=> stuck button, endless hitting).
  const int w = (e.button == g.lmbCode.load()) ? 0 : (e.button == g.rmbCode.load() ? 1 : -1);
  auto consume = [&](bool down) -> bool {
    if (w < 0) return false;
    std::atomic<int> &ctr = down ? g.expDown[w] : g.expUp[w];
    if (ctr.load() > 0) { ctr.fetch_sub(1); return true; }
    return false;
  };
  if (std::hash<std::thread::id>{}(std::this_thread::get_id()) == g.workerTid.load()) {
    consume(e.isDown); // synchronous echo of our own click
    return false;
  }
  if (w >= 0 && nowMs() < g.expDeadline[w].load() && consume(e.isDown)) return false;

  static int loggedMouse = 0;
  if (loggedMouse < 20) {
    ++loggedMouse;
    diag("mouse event: button=" + std::to_string(e.button) +
         " down=" + (e.isDown ? "1" : "0"));
  }
  if (gLog) gLog->info("mouse event: button={} down={}", e.button, e.isDown);

  // Physical buttons are always 1 = LMB, 2 = RMB. The configurable codes only
  // affect the echo filter; using them for held-state made a stale menu value
  // silently disable the whole mod.
  const int btn = e.button;
  if (btn == 1) {
    g.lmbHeld = e.isDown;
    if (e.isDown) g.rmbHeld = false;
  } else if (btn == 2) {
    g.rmbHeld = e.isDown;
    if (e.isDown) g.lmbHeld = false;
  } else if (btn == g.lmbCode.load()) {
    g.lmbHeld = e.isDown;
    if (e.isDown) g.rmbHeld = false;
  } else if (btn == g.rmbCode.load()) {
    g.rmbHeld = e.isDown;
    if (e.isDown) g.lmbHeld = false;
  }

  static int loggedState = 0;
  if (loggedState < 8) {
    ++loggedState;
    diag("state: btn=" + std::to_string(btn) +
         " lmbHeld=" + (g.lmbHeld.load() ? "1" : "0") +
         " rmbHeld=" + (g.rmbHeld.load() ? "1" : "0") +
         " mod=" + std::to_string(g.lmbMod.load()) +
         " on=" + (g.lmbOn.load() ? "1" : "0") +
         " module=" + (g.lmbModuleEnabled.load() ? "1" : "0") +
         " method=" + std::to_string(g.lmbMethod.load()) +
         " cps=" + std::to_string(g.lmbCps.load()));
  }
  return false; // never swallow real input
}

bool onTouch(const pl::input::TouchEvent &e) {
  g.lastX = e.x;
  g.lastY = e.y;
  return false;
}

void onConfigChanged(std::string_view /*moduleId*/, std::string_view key,
                     std::string_view value) {
  if (gLog) {
    const std::string k(key), v(value);
    gLog->info("config {} = {}", k, v);
  }
  if (key == "lmb_on") g.lmbOn = parseBool(value);
  else if (key == "rmb_on") g.rmbOn = parseBool(value);
  else if (key == "lmb_cps") g.lmbCps = parseInt(value, 20, 1, 30);
  else if (key == "rmb_cps") g.rmbCps = parseInt(value, 20, 1, 30);
  else if (key == "lmb_code") g.lmbCode = parseInt(value, 1, 0, 8);
  else if (key == "rmb_code") g.rmbCode = parseInt(value, 2, 0, 8);
  else if (key == "lmb_mod") g.lmbMod = parseInt(value, 0, 0, 3);
  else if (key == "rmb_mod") g.rmbMod = parseInt(value, 0, 0, 3);
  else if (key == "lmb_method") g.lmbMethod = parseInt(value, 4, 0, 4);
  else if (key == "rmb_method") g.rmbMethod = parseInt(value, 4, 0, 4);
}

// ---------------------------------------------------------------- click injection (JNI)
// LeviLauncher delivers real mouse buttons to native mods as KeyEvents
// (KEYCODE_BUTTON_1 / KEYCODE_BUTTON_2) through Activity.dispatchKeyEvent,
// NOT as touch MotionEvents. The old injector built synthetic MotionEvents,
// which the launcher treated as touches at (0,0) -- so no click ever reached
// Minecraft. We now dispatch the exact same KeyEvents a real mouse click uses.
class Injector {
 public:
  explicit Injector(pl::log::Logger *log) : mLog(log) {}

  bool click(JNIEnv *env, int which, int method) {
    if (!mPrepared) {
      mPrepared = prepare(env);
      if (!mPrepared) return false;
    }
    if (!mActivity) {
      mActivity = resolveActivity(env);
      if (!mActivity) {
        if (!mWarnedNoActivity) {
          mWarnedNoActivity = true;
          mLog->error("injector: could not find the game Activity");
          diag("injector: could not find the game Activity");
        }
        return false;
      }
      mLog->info("injector: Activity found");
      diag("injector: Activity found");
    }

    // Expect exactly one down + one up echo of our own click. Do NOT use a
    // time window: it used to eat real button-up events.
    g.expDown[which] = 1;
    g.expUp[which] = 1;
    g.expDeadline[which] = nowMs() + 60;
    env->PushLocalFrame(64); // the worker thread never returns to Java: free local refs every click
    bool ok = false;
    const jint key = which == 0 ? kKeyMouseLeft : kKeyMouseRight;
    if (method == 4) {
      ok = dispatchLegacy(env, key);
    } else if (method <= 1) {
      ok = dispatch(env, key, method == 1 ? kSourceMouse : kSourceKeyboard, method);
    } else {
      ok = dispatchMotion(env, which, method);
    }
    env->PopLocalFrame(nullptr);
    g.expDeadline[which] = nowMs() + 25; // async echo, if any, arrives right away
    if (!ok) { g.expDown[which] = 0; g.expUp[which] = 0; }
    if (!ok) {
      env->DeleteGlobalRef(mActivity);
      mActivity = nullptr;
    }
    return ok;
  }

 private:
  pl::log::Logger *mLog;
  bool mPrepared = false;
  bool mWarnedNoActivity = false;
  int mLoggedResults = 0;

  jclass mKeyEvent = nullptr;
  jmethodID mCtor = nullptr;
  jmethodID mDispatch = nullptr;
  jobject mActivity = nullptr;  // global ref

  static bool pending(JNIEnv *env) {
    if (!env->ExceptionCheck()) return false;
    env->ExceptionClear();
    return true;
  }

  jclass globalClass(JNIEnv *env, const char *name) {
    jclass local = env->FindClass(name);
    const bool threw = pending(env); // MUST be called: clears the JNI exception
    if (!local || threw) {
      mLog->error("injector: class not found: {}", std::string(name));
      return nullptr;
    }
    jclass global = static_cast<jclass>(env->NewGlobalRef(local));
    env->DeleteLocalRef(local);
    return global;
  }

  bool prepare(JNIEnv *env) {
    mKeyEvent = globalClass(env, "android/view/KeyEvent");
    jclass activityCls = env->FindClass("android/app/Activity");
    if (pending(env) || !mKeyEvent || !activityCls) {
      mLog->error("injector: required Android classes are missing");
      diag("injector: required Android classes are missing");
      return false;
    }
    // KeyEvent(downTime, eventTime, action, code, repeat, meta, deviceId,
    //          scancode, flags, source)
    mCtor = env->GetMethodID(mKeyEvent, "<init>", "(JJIIIIIIII)V");
    mDispatch = env->GetMethodID(activityCls, "dispatchKeyEvent",
                                 "(Landroid/view/KeyEvent;)Z");
    if (pending(env) || !mCtor || !mDispatch) {
      mLog->error("injector: required Android methods were not found");
      diag("injector: required Android methods were not found");
      return false;
    }
    diag("injector: prepared (KeyEvent path)");
    mLog->info("injector: prepared (KeyEvent path)");
    return true;
  }

  // Looks the foreground Activity up through ActivityThread (hidden API,
  // may be blocked on some devices).
  jobject resolveActivity(JNIEnv *env) {
    env->PushLocalFrame(64);
    jobject result = nullptr;
    do {
      jclass atCls = env->FindClass("android/app/ActivityThread");
      bool threw = pending(env);
      if (!atCls || threw) { mLog->error("injector: ActivityThread not found"); break; }
      jmethodID current = env->GetStaticMethodID(atCls, "currentActivityThread",
                                                 "()Landroid/app/ActivityThread;");
      threw = pending(env);
      if (!current || threw) { mLog->error("injector: currentActivityThread not found"); break; }
      jobject thread = env->CallStaticObjectMethod(atCls, current);
      if (pending(env) || !thread) { mLog->error("injector: no ActivityThread instance"); break; }
      jfieldID activitiesField = env->GetFieldID(atCls, "mActivities", "Landroid/util/ArrayMap;");
      threw = pending(env);
      if (!activitiesField || threw) { mLog->error("injector: mActivities not accessible"); break; }
      jobject map = env->GetObjectField(thread, activitiesField);
      if (!map) break;
      jclass mapCls = env->FindClass("android/util/ArrayMap");
      jmethodID sizeM = env->GetMethodID(mapCls, "size", "()I");
      jmethodID valueAt = env->GetMethodID(mapCls, "valueAt", "(I)Ljava/lang/Object;");
      if (pending(env) || !sizeM || !valueAt) break;
      const jint n = env->CallIntMethod(map, sizeM);
      jobject fallback = nullptr;
      for (jint i = 0; i < n; ++i) {
        jobject record = env->CallObjectMethod(map, valueAt, i);
        if (pending(env) || !record) continue;
        jclass recCls = env->GetObjectClass(record);
        jfieldID actField = env->GetFieldID(recCls, "activity", "Landroid/app/Activity;");
        threw = pending(env);
        if (!actField || threw) continue;
        jobject act = env->GetObjectField(record, actField);
        if (!act) continue;
        jfieldID pausedField = env->GetFieldID(recCls, "paused", "Z");
        const bool pausedThrew = pending(env); // always clear, never short-circuit
        bool paused = false;
        if (!pausedThrew && pausedField) paused = env->GetBooleanField(record, pausedField);
        if (!paused) { result = act; break; }
        if (!fallback) fallback = act;
      }
      if (!result) result = fallback;
    } while (false);
    jobject global = result ? env->NewGlobalRef(result) : nullptr;
    env->PopLocalFrame(nullptr);
    return global;
  }

  bool dispatch(JNIEnv *env, jint keyCode, jint source, int method) {
    jclass clockCls = env->FindClass("android/os/SystemClock");
    jmethodID uptime = clockCls ? env->GetStaticMethodID(clockCls, "uptimeMillis", "()J") : nullptr;
    if (pending(env) || !uptime) {
      mLog->error("injector: SystemClock.uptimeMillis not found");
      diag("injector: SystemClock.uptimeMillis not found");
      return false;
    }
    const jlong t = env->CallStaticLongMethod(clockCls, uptime);
    // action 0 = DOWN, 1 = UP; source 0x2002 = SOURCE_MOUSE.
    jobject down = env->NewObject(mKeyEvent, mCtor, t, t, (jint)0, keyCode,
                                  (jint)0, (jint)0, (jint)-1, (jint)0,
                                  (jint)0, source);
    jobject up = env->NewObject(mKeyEvent, mCtor, t, t + 10, (jint)1, keyCode,
                                (jint)0, (jint)0, (jint)-1, (jint)0,
                                (jint)0, source);
    if (pending(env) || !down || !up) {
      mLog->error("injector: could not build KeyEvent");
      diag("injector: could not build KeyEvent");
      return false;
    }
    const jboolean hDown = env->CallBooleanMethod(mActivity, mDispatch, down);
    bool threw = pending(env);
    const jboolean hUp = env->CallBooleanMethod(mActivity, mDispatch, up);
    threw |= pending(env);
    if (mLoggedResults < 12) {
      ++mLoggedResults;
      mLog->info("injector: dispatch key={} exception={}", keyCode, threw ? 1 : 0);
      diag("injector: dispatch method=" + std::to_string(method) + " key=" + std::to_string(keyCode) +
           " handledDown=" + (hDown ? "1" : "0") + " handledUp=" + (hUp ? "1" : "0") +
           " exception=" + (threw ? "1" : "0"));
    }
    return !threw;
  }

  // ---- Legacy Ctrl path (method 4) -------------------------------------
  // Reproduces the exact state that made 2.7 work: KeyEvents with
  // META_CTRL_ON + SOURCE_MOUSE + FLAG_FROM_SYSTEM while Ctrl is held.
  bool dispatchLegacy(JNIEnv *env, jint keyCode) {
    jclass clockCls = env->FindClass("android/os/SystemClock");
    jmethodID uptime = clockCls ? env->GetStaticMethodID(clockCls, "uptimeMillis", "()J") : nullptr;
    if (pending(env) || !uptime) return false;
    const jlong t = env->CallStaticLongMethod(clockCls, uptime);
    // The old build only worked because the click carried Ctrl state. We
    // embed that state unconditionally now -- physical Ctrl is not needed.
    const jint meta = 0x1000; // META_CTRL_ON
    const jint flags = static_cast<jint>(0x80000000u);                      // FLAG_FROM_SYSTEM
    jobject down = env->NewObject(mKeyEvent, mCtor, t, t, (jint)0, keyCode,
                                  (jint)0, meta, (jint)0, (jint)0,
                                  flags, kSourceMouse);
    jobject up = env->NewObject(mKeyEvent, mCtor, t, t + 10, (jint)1, keyCode,
                                (jint)0, meta, (jint)0, (jint)0,
                                flags, kSourceMouse);
    if (pending(env) || !down || !up) return false;
    const jboolean hDown = env->CallBooleanMethod(mActivity, mDispatch, down);
    bool threw = pending(env);
    const jboolean hUp = env->CallBooleanMethod(mActivity, mDispatch, up);
    threw |= pending(env);
    if (mLoggedResults < 12) {
      ++mLoggedResults;
      diag("injector: dispatch method=4 legacy key=" + std::to_string(keyCode) +
           " meta=0x" + std::to_string(meta) +
           " source=0x2002 flags=FROM_SYSTEM" +
           " handledDown=" + (hDown ? "1" : "0") +
           " handledUp=" + (hUp ? "1" : "0") +
           " exception=" + (threw ? "1" : "0"));
    }
    return !threw;
  }

  // ---- MotionEvent path (methods 2 and 3) -------------------------------
  // Method 2: ACTION_DOWN / ACTION_UP (mouse source) through the decor view.
  // Method 3: the full sequence a real mouse produces:
  //           DOWN -> BUTTON_PRESS -> BUTTON_RELEASE -> UP.
  bool dispatchMotion(JNIEnv *env, int which, int method) {
    jclass meCls = env->FindClass("android/view/MotionEvent");
    jclass ppCls = env->FindClass("android/view/MotionEvent$PointerProperties");
    jclass pcCls = env->FindClass("android/view/MotionEvent$PointerCoords");
    jclass scCls = env->FindClass("android/os/SystemClock");
    jclass viewCls = env->FindClass("android/view/View");
    jclass windowCls = env->FindClass("android/view/Window");
    jclass activityCls = env->FindClass("android/app/Activity");
    if (pending(env) || !meCls || !ppCls || !pcCls || !scCls || !viewCls || !windowCls || !activityCls) {
      diag("injector: motion classes missing");
      return false;
    }
    jmethodID obtain = env->GetStaticMethodID(
        meCls, "obtain",
        "(JJII[Landroid/view/MotionEvent$PointerProperties;"
        "[Landroid/view/MotionEvent$PointerCoords;IIFFIIII)Landroid/view/MotionEvent;");
    jmethodID recycle = env->GetMethodID(meCls, "recycle", "()V");
    jmethodID setActionButton = env->GetMethodID(meCls, "setActionButton", "(I)V");
    if (pending(env)) setActionButton = nullptr;
    jmethodID ppCtor = env->GetMethodID(ppCls, "<init>", "()V");
    jmethodID pcCtor = env->GetMethodID(pcCls, "<init>", "()V");
    jfieldID ppId = env->GetFieldID(ppCls, "id", "I");
    jfieldID ppTool = env->GetFieldID(ppCls, "toolType", "I");
    jfieldID pcX = env->GetFieldID(pcCls, "x", "F");
    jfieldID pcY = env->GetFieldID(pcCls, "y", "F");
    jfieldID pcPressure = env->GetFieldID(pcCls, "pressure", "F");
    jfieldID pcSize = env->GetFieldID(pcCls, "size", "F");
    jmethodID uptime = env->GetStaticMethodID(scCls, "uptimeMillis", "()J");
    jmethodID getWindow = env->GetMethodID(activityCls, "getWindow", "()Landroid/view/Window;");
    jmethodID getDecor = env->GetMethodID(windowCls, "getDecorView", "()Landroid/view/View;");
    jmethodID dTouch = env->GetMethodID(viewCls, "dispatchTouchEvent", "(Landroid/view/MotionEvent;)Z");
    jmethodID dGeneric = env->GetMethodID(viewCls, "dispatchGenericMotionEvent", "(Landroid/view/MotionEvent;)Z");
    jmethodID vW = env->GetMethodID(viewCls, "getWidth", "()I");
    jmethodID vH = env->GetMethodID(viewCls, "getHeight", "()I");
    if (pending(env) || !obtain || !recycle || !ppCtor || !pcCtor || !ppId || !ppTool || !pcX || !pcY ||
        !pcPressure || !pcSize || !uptime || !getWindow || !getDecor || !dTouch || !dGeneric || !vW || !vH) {
      diag("injector: motion methods missing");
      return false;
    }
    jobject window = env->CallObjectMethod(mActivity, getWindow);
    if (pending(env) || !window) { diag("injector: no window"); return false; }
    jobject decor = env->CallObjectMethod(window, getDecor);
    if (pending(env) || !decor) { diag("injector: no decor view"); return false; }

    float x = g.lastX.load(), y = g.lastY.load();
    if (x < 0.0f || y < 0.0f) {
      x = env->CallIntMethod(decor, vW) / 2.0f;
      y = env->CallIntMethod(decor, vH) / 2.0f;
      pending(env);
    }
    const jint bs = which == 0 ? kButtonPrimary : kButtonSecondary;

    struct Step { jint action; jint buttonState; jint actionButton; bool generic; };
    const Step touchSteps[] = {{kActionDown, bs, 0, false}, {kActionUp, 0, 0, false}};
    const Step fullSteps[] = {{kActionDown, bs, 0, false},
                              {kActionButtonPress, bs, bs, true},
                              {kActionButtonRelease, 0, bs, true},
                              {kActionUp, 0, 0, false}};
    const Step *steps = method == 2 ? touchSteps : fullSteps;
    const int count = method == 2 ? 2 : 4;

    for (int i = 0; i < count; ++i) {
      const Step &st = steps[i];
      jobject props = env->NewObject(ppCls, ppCtor);
      jobject coords = env->NewObject(pcCls, pcCtor);
      if (pending(env) || !props || !coords) return false;
      env->SetIntField(props, ppId, 0);
      env->SetIntField(props, ppTool, 3); // TOOL_TYPE_MOUSE
      env->SetFloatField(coords, pcX, x);
      env->SetFloatField(coords, pcY, y);
      env->SetFloatField(coords, pcPressure, st.buttonState ? 1.0f : 0.0f);
      env->SetFloatField(coords, pcSize, 1.0f);
      jobjectArray propsArr = env->NewObjectArray(1, ppCls, nullptr);
      jobjectArray coordsArr = env->NewObjectArray(1, pcCls, nullptr);
      if (pending(env) || !propsArr || !coordsArr) return false;
      env->SetObjectArrayElement(propsArr, 0, props);
      env->SetObjectArrayElement(coordsArr, 0, coords);
      const jlong t = env->CallStaticLongMethod(scCls, uptime);
      jobject ev = env->CallStaticObjectMethod(
          meCls, obtain, t, t, st.action, (jint)1, propsArr, coordsArr, (jint)0, st.buttonState,
          1.0f, 1.0f, (jint)0, (jint)0, kSourceMouse, (jint)0);
      if (pending(env) || !ev) { diag("injector: could not build MotionEvent"); return false; }
      if (st.actionButton && setActionButton) {
        env->CallVoidMethod(ev, setActionButton, st.actionButton);
        pending(env);
      }
      const jboolean handled = env->CallBooleanMethod(decor, st.generic ? dGeneric : dTouch, ev);
      const bool threw = pending(env);
      env->CallVoidMethod(ev, recycle);
      pending(env);
      if (mLoggedResults < 12) {
        ++mLoggedResults;
        diag("injector: dispatch method=" + std::to_string(method) + " action=" + std::to_string(st.action) +
             " handled=" + (handled ? "1" : "0") + " exception=" + (threw ? "1" : "0"));
      }
      if (threw) return false;
    }
    return true;
  }
};

// ---------------------------------------------------------------- worker thread
class Worker {
public:
  void start(JavaVM *vm, pl::log::Logger *log) {
    if (mRunning.exchange(true)) return;
    mThread = std::thread([this, vm, log] { run(vm, log); });
  }

  void stop() {
    mRunning = false;
    if (mThread.joinable()) mThread.join();
  }

private:
  std::atomic<bool> mRunning{false};
  std::thread mThread;

  void run(JavaVM *vm, pl::log::Logger *log) {
    JNIEnv *env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) {
      log->error("worker: AttachCurrentThread failed");
      diag("worker: AttachCurrentThread failed");
      mRunning = false;
      return;
    }
    g.workerTid = std::hash<std::thread::id>{}(std::this_thread::get_id());
    log->info("worker: started");
    diag("worker: started (2.13-forced)");
    Injector injector(log);
    Clock::time_point next[2]{};
    bool wasActive[2]{false, false};

    while (mRunning.load()) {
      std::this_thread::sleep_for(std::chrono::milliseconds(3));
      const bool held[2] = {g.lmbHeld.load(), g.rmbHeld.load()};
      const bool on[2] = {g.lmbOn.load(), g.rmbOn.load()};
      const int cps[2] = {g.lmbCps.load(), g.rmbCps.load()};
      const int mods[2] = {g.lmbMod.load(), g.rmbMod.load()};
      // Dispatch the same KeyEvents the launcher produces for real clicks.
      const int methods[2] = {g.lmbMethod.load(), g.rmbMethod.load()};

      for (int i = 0; i < 2; ++i) {
        bool modHeld = false;
        switch (mods[i]) {
          case 0: modHeld = true; break; // no modifier
          case 1: modHeld = g.ctrlLeft.load() || g.ctrlRight.load(); break;
          case 2: modHeld = g.shiftLeft.load() || g.shiftRight.load(); break;
          case 3: modHeld = g.altLeft.load() || g.altRight.load(); break;
          default: modHeld = true; break;
        }
        // Legacy method IS the working 2.7 mechanism, embedded directly:
        // hold the mouse button => repeat. No Ctrl, no menu toggles, no saved
        // config can suppress it.
        const bool active = (methods[i] == 4)
            ? held[i]
            : ((i == 0 ? g.lmbModuleEnabled.load() : g.rmbModuleEnabled.load()) &&
               modHeld && on[i] && held[i]);
        if (!active) { wasActive[i] = false; continue; }
        const auto now = Clock::now();
        const auto interval = std::chrono::milliseconds(1000 / std::clamp(cps[i], 1, 30));
        if (!wasActive[i]) {
          // Fire immediately: a short tap (~70 ms) never reached the old
          // code because it waited a whole interval before the first click.
          wasActive[i] = true;
          next[i] = now + interval;
          diag("repeat: start which=" + std::to_string(i) +
               " method=" + std::to_string(methods[i]));
          injector.click(env, i, methods[i]);
          continue;
        }
        if (now >= next[i]) {
          next[i] = now + interval;
          injector.click(env, i, methods[i]);
        }
      }
    }
    log->info("worker: stopped");
    diag("worker: stopped");
    vm->DetachCurrentThread();
  }
};

Worker gWorker;
bool gCallbacksRegistered = false;

} // namespace

// ---------------------------------------------------------------- mod lifecycle
class ClickRepeaterMod {
public:
  static ClickRepeaterMod &getInstance() {
    static ClickRepeaterMod instance;
    return instance;
  }

  bool load(ll::mod::ModContext &ctx) {
    ctx.logger().info("loaded");
    return true;
  }

  bool enable(ll::mod::ModContext &ctx) {
    gLog = &ctx.logger();
    g.active = true;
    diag("enable: Click Repeater 2.13-forced");

    if (!gCallbacksRegistered) { // the SDK has no way to unregister callbacks
      pl::input::registerKeyCallback(onKey);
      pl::input::registerMouseCallback(onMouse);
      pl::input::registerTouchCallback(onTouch);
      gCallbacksRegistered = true;
    }

    // Two separate modules => two top-level tabs in the Levi Mod Menu.
    pl::modmenu::ModuleBuilder lmb(kModuleLmb, "Click Repeater LMB");
    lmb.description("Auto-repeat for the LEFT mouse button")
        .defaultEnabled(true)
        .onToggle([](std::string_view, bool enabled) { g.lmbModuleEnabled = enabled; })
        .onConfigChanged(onConfigChanged)
        .config("lmb_on", "LMB: enabled", pl::modmenu::ConfigType::Toggle, "true")
        .config("lmb_cps", "LMB: clicks per second", pl::modmenu::ConfigType::SliderInt, "20", "1", "30")
        .config("lmb_mod", "LMB: mode 1-4", pl::modmenu::ConfigType::Radio, "0",
                "None,Ctrl,Shift,Alt")
        .config("lmb_code", "LMB: button code", pl::modmenu::ConfigType::SliderInt, "1", "0", "8")
        .config("lmb_method", "LMB: inject method", pl::modmenu::ConfigType::Radio, "4",
                "Key,KeyMouse,Touch,Full,LegacyCtrl");
    const bool okLmb = lmb.registerModule();

    pl::modmenu::ModuleBuilder rmb(kModuleRmb, "Click Repeater RMB");
    rmb.description("Auto-repeat for the RIGHT mouse button")
        .defaultEnabled(true)
        .onToggle([](std::string_view, bool enabled) { g.rmbModuleEnabled = enabled; })
        .onConfigChanged(onConfigChanged)
        .config("rmb_on", "RMB: enabled", pl::modmenu::ConfigType::Toggle, "true")
        .config("rmb_cps", "RMB: clicks per second", pl::modmenu::ConfigType::SliderInt, "20", "1", "30")
        .config("rmb_mod", "RMB: mode 1-4", pl::modmenu::ConfigType::Radio, "0",
                "None,Ctrl,Shift,Alt")
        .config("rmb_code", "RMB: button code", pl::modmenu::ConfigType::SliderInt, "2", "0", "8")
        .config("rmb_method", "RMB: inject method", pl::modmenu::ConfigType::Radio, "4",
                "Key,KeyMouse,Touch,Full,LegacyCtrl");
    const bool okRmb = rmb.registerModule();
    ctx.logger().info("menu modules registered: lmb={} rmb={}", okLmb, okRmb);

    gWorker.start(ctx.javaVm(), &ctx.logger());
    return true;
  }

  bool disable(ll::mod::ModContext &ctx) {
    g.active = false;
    gWorker.stop();
    pl::modmenu::unregisterModule(kModuleLmb);
    pl::modmenu::unregisterModule(kModuleRmb);
    ctx.logger().info("disabled");
    return true;
  }

  bool unload(ll::mod::ModContext &ctx) {
    ctx.logger().info("unloaded");
    return true;
  }

private:
  ClickRepeaterMod() = default;
};

} // namespace clickrepeater

PL_REGISTER_MOD(clickrepeater::ClickRepeaterMod, clickrepeater::ClickRepeaterMod::getInstance());
